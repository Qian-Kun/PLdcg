#ifndef VERSION_H_
#define VERSION_H_

static char *aln_version = "0.1.5";
static char *aln_date = "May 3, 2006";

#endif
