#include "align.h"

int main(int argc, char *argv[])
{
	return pwalign_task(argc, argv);
}
